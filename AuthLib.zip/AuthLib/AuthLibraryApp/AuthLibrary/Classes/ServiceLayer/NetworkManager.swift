//
//  NetworkManager.swift
//  AuthLibrary-AuthLibrary
//
//  Created by Kanakaraju Chinnam on 4/18/23.
//

import Foundation

struct User: Codable {
    let email: String
    let password: String
}

enum NetworkError: Error {
    case badURL
    case networkError
    case decodingError
    case encodingError
}

class NetworkManager {
    static let shared = NetworkManager()
    
    func login(user: User) async throws -> LoginResponse {
        guard let url = URL(string: "https://api.com/login") else {
            throw NetworkError.badURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            request.httpBody = try JSONEncoder().encode(user)
        } catch {
            throw NetworkError.encodingError
        }
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw NetworkError.networkError
        }
        
        do {
            let response = try JSONDecoder().decode(LoginResponse.self, from: data)
            return response
        } catch {
            throw NetworkError.decodingError
        }
    }
    
    func signUp(user: User) async throws -> SignUpResponse {
        guard let url = URL(string: "https://api.com/signup") else {
            throw NetworkError.badURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            request.httpBody = try JSONEncoder().encode(user)
        } catch {
            throw NetworkError.encodingError
        }
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw NetworkError.networkError
        }
        
        do {
            let response = try JSONDecoder().decode(SignUpResponse.self, from: data)
            return response
        } catch {
            throw NetworkError.decodingError
        }
    }
}



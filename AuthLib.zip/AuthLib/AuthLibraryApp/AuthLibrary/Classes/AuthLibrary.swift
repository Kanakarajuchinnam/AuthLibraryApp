import Foundation

public class AuthLibrary {
    
    public init() {
        
    }
    
    public func getRootViewController() -> UIViewController? {
        guard let viewController: BaseViewController = UIStoryboard(name: "AuthLibrary", bundle: Bundle.authBundle()).instantiateInitialViewController() as? BaseViewController else { return nil }
        return viewController
    }
}

extension Bundle {
    static func authBundle() -> Bundle? {
        let bundle = Bundle(for: AuthLibrary.self)
        guard let url = bundle.url(forResource: "AuthLibrary", withExtension: "bundle") else {
            return nil
        }
        return Bundle(url: url)
    }
}

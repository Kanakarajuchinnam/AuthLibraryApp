//
//  SignInView.swift
//  AuthLibrary-AuthLibrary
//
//  Created by Kanakaraju Chinnam on 4/18/23.
//

import SwiftUI

struct SignInView: View {
    @StateObject var viewModel = SignInViewModel()
    @State private var email = ""
    @State private var password = ""
    
    var body: some View {
        VStack {
            Spacer()
            Image(systemName: "lock.shield")
                .resizable()
                .scaledToFit()
                .frame(width: 100, height: 100)
                .foregroundColor(.blue)
            
            Text("Log In")
                .font(.title)
                .bold()
                .foregroundColor(.blue)
            VStack {
                TextField("Email", text: $email)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                
                SecureField("Password", text: $password)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
            }.padding([.leading, .trailing], 20)
                .padding(.top, 20)
            
            Button(action: {
                Task {
                    await viewModel.signIn()
                }
            }) {
                Text("Log In")
                    .foregroundColor(.white)
                    .font(.headline)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.blue)
                    .cornerRadius(25)
                    .padding(.top, 30)
            }
            
            if viewModel.isLoading {
                ProgressView()
            }
            if !viewModel.errorMessage.isEmpty {
                Text(viewModel.errorMessage)
            }
            
            Spacer()
            Spacer()
            Button(action: {
                SignUpView()
            }) {
                Text("Already have account?")
                    .foregroundColor(.blue)
                    .font(.headline)
                    .padding()
            }

        }
        .padding(.top, 50)
    }
}

struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
    }
}

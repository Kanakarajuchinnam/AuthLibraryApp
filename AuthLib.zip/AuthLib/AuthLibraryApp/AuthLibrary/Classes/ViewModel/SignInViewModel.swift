//
//  SignInViewModel.swift
//  AuthLibrary-AuthLibrary
//
//  Created by Kanakaraju Chinnam on 4/18/23.
//

import Foundation
import Combine

class SignInViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    @Published var errorMessage = ""
    @Published var isLoading = false
    @Published var isSignedIn = false
    
    private let networkManager = NetworkManager.shared
    
    func signIn() async {
        
        let user = User(email: email, password: password)
        
        do {
            let response = try await networkManager.login(user: user)
            print(response)
//            if let = resonse.token {
//                UserDefaults.standard.setValue(true, forKey: "isLoggedIn")
//            }
            isSignedIn = true
        } catch {
            errorMessage = "Invalid email or password"
        }
        
        isLoading = false
    }
}

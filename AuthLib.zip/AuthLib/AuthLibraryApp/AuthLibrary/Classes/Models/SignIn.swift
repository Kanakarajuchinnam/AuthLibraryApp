//
//  File.swift
//  AuthLibrary
//
//  Created by Kanakaraju Chinnam on 4/18/23.
//

import Foundation

struct LoginResponse: Codable {
    let token: String?
    let userInfo: [String: String]?
}

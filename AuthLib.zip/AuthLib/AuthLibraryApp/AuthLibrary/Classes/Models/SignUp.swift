//
//  SignUp.swift
//  AuthLibrary
//
//  Created by Kanakaraju Chinnam on 4/18/23.
//

import Foundation

struct SignUpResponse: Codable {
    let success: Bool?
}

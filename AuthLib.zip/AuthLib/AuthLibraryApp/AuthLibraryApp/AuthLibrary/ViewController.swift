//
//  ViewController.swift
//  AuthLibrary
//
//  Created by Kanakaraju Chinnam on 4/18/23.
//

import UIKit
import AuthLibrary

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        setupBaseViewController()
    }
    
    private func setupBaseViewController() {
        guard let viewcontroller = AuthLibrary().getRootViewController() else {
            return
        }
        self.addChildViewController(viewcontroller)
        self.view.addSubview(viewcontroller.view)
        viewcontroller.didMove(toParentViewController: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

